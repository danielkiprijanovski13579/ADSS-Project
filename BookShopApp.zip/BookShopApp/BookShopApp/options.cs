﻿namespace BookShopApp
{
    internal class options
    {
    }
}