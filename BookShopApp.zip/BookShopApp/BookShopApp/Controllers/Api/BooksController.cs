﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

using BookShopApp.Models;
using BookShopApp.Data;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookShopApp.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private object BooksDB;

        // GET: api/<BooksController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<BooksController>/5
        [HttpGet("{pageNum}", Name = "Get")]
        public IEnumerable<Book> Get(int pageNum)
        {
            int pageSize = 4;
            int startPosition = (pageNum - 1) * pageSize;

            using (var context = new BooksDB())
            {
                List<Book> books = context.Books.ToList();
                if (books.Count >= startPosition)
                {
                    return books.Skip(startPosition).Take(pageSize);
                }
                else
                {
                    return new List<Book>();
                }
            }
        }


        // POST api/<BooksController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }
        /*
        [HttpPost]
        public void Post([FromBody] Booksss model)
        {
            if (!string.IsNullOrEmpty(model.Name))
{
                model.Name = BooksDB.Books.FullTextSearchQuery(model.Name);
            }
            else
        {
                model.Books = BooksDB.Books;
            }
        }
        */

        // PUT api/<BooksController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<BooksController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
